<?php
require('../fpdf.php');
require('conexionsimple.php');

$num = 1;
$id = $_GET['rfc'];
$consulta =" SELECT id, rfc, fecha, cantidadAbono, pago, saldoActualizado FROM t_abono WHERE t_abono.rfc='$id'";
$resultado = $mysqli->query($consulta);
class PDF extends FPDF
{
// Cabecera de p�gina
function Header()
{
    $id = $_GET['rfc'];
	$cadena1 ="ó";
    $cadena2 = mb_convert_encoding($cadena1, 'UTF-16','UTF-8');
    $cadena3 =ltrim($cadena2);
    $cadena4 ="é";
    $cadena5 = mb_convert_encoding($cadena4, 'UTF-16','UTF-8');
    $cadena6 = ltrim($cadena5);
    $cadena7 ="ú";
    $cadena8 = mb_convert_encoding($cadena7, 'UTF-16','UTF-8');
    $cadena9 =ltrim($cadena8);

	// Logo
	$this->Image('logo.png',10,8,33);
	$this->SetFont('Arial','B',15);
    $this->cell(100);

	$this->Cell(30,10,'Universidad Aut'.$cadena3.'noma de Chiapas',0,0,'C');
    $this->Cell(-30,20, 'Licenciatura en Sistemas Computacionales',0,0,'C');
    $this->Cell(30,40,'Administraci'.$cadena3. 'n de Base De Datos',0,0,'C');

	$this->Ln(40);
    $this->SetFont('Arial','B',12);
    $this->SetTextColor(255,255,255);
    $this->SetFillColor(21,67,96);

	$this->SetDrawColor(255,255,255);
    $this->SetLineWidth(0);

	$this->Cell(10,10,'N'.$cadena9. 'm',1,0,'C',true);
    $this->Cell(50,10,'rfc',1,0,'C',true);
    $this->Cell(40,10,'Fecha',1,0,'C',true);
    $this->Cell(40,10,'Cantidad de Abono',1,0,'C',true);
    $this->Cell(55,10,'Pago',1,0,'C',true);
    $this->Cell(55,10,'Saldo Actual'.$cadena6. 'fono',1,1,'C',true);
    

}

// Pie de p�gina
function Footer()
{
	$this->SetY(-15);
    $this->SetFont('Arial','I',8);
	$cadena10 ="á";
    $cadena11 = mb_convert_encoding($cadena10,'UTF-16','UTF-8');
    $cadena12 =ltrim($cadena11);
	$this->Cell(0,10,'P' .$cadena12. 'gina' .$this->PageNo(). '/{nb}',0,0,'C');
}
}

// Creaci�n del objeto de la clase heredada
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage('LANDSCAPE','letter');
$pdf->SetFont('Courier','',12);

while($row = $resultado->fetch_assoc()){
    $pdf->Cell(10,10,$row['id'],'B',0,'C',0);
    $pdf->Cell(50,10,$row['rfc'],'B',0,'C',0);
    $pdf->Cell(40,10,$row['fecha'],'B',0,'C',0);
    $pdf->Cell(40,10,$row['cantidadAbono'],'B',0,'C',0);
    $pdf->Cell(50,10,$row['pago'],'B',0,'C',0);
    $pdf->Cell(45,10,$row['saldoActualizado'],'B',1,'C',0);
    
    //$num = $num+1;
}
$pdf->Output();
mysqli_close($mysqli);
?>
