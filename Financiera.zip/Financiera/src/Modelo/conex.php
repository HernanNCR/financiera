<?php
    $servidor = 'localhost';
    $usuario = 'root';
    $password = 'root';
    $bd= 'financiera1';
    $conecta= mysqli_connect($servidor,$usuario,$password,$bd);
    if($conecta->connect_error){
        die("error".$conecta->connect_error);
    }
?>