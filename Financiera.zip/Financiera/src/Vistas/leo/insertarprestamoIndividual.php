<?php

include '../modelo/conex.php';
  $consulta= "SELECT * FROM t_cliente";
  $resultado= $conecta->query($consulta);
  $id = $_GET['rfc'];

  if (isset($_POST['registrar'])){
    $mensaje="";
    $nump = $conecta->real_escape_string($_POST['id']);
    $rfc = $conecta->real_escape_string($_POST['rfc']);
    $fecha = $conecta->real_escape_string($_POST['fecha']);
    $cantidad = $conecta->real_escape_string($_POST['numero']);
    $tpago = $conecta->real_escape_string($_POST['tpago']);
    $saldo = $conecta->real_escape_string($_POST['SaldoActualizado']);

    $insertar = "INSERT INTO t_abono (id, rfc, fecha, cantidadAbono, pago, saldoActualizado)VALUES('$nump', '$rfc', '$fecha', '$cantidad', '$tpago', '$saldo')";
    $guardando = $conecta->query($insertar);
    if($guardando > 0){
        $mensaje.= "<h3 class='text-success'>Tu registro se realizo con exito</h3>";
        echo $tpago;
    }
    else{
        $mensaje.= "<h3 class='text-danger'>Tu registro no se realizo con exito</h3>";
        echo $rfc;
    }
  }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="../vistas/style2.css">
</head>
<body>
    
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="well well-sm">
                <form class="form-horizontal" method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                    <fieldset>
                        <legend class="text-center header">Abono</legend>

                        <div class="form-group">
                            <span class="col-md-1 col-md-offset-2 text-center"><i class="fa fa-phone-square bigicon"></i></span>
                            <div class="col-md-8">
                                <input id="phone" name="id" type="text" placeholder="Numero de Pago" class="form-control">
                            </div>
                        </div>
                        <br>
                        <div class="form-group">
                            <span class="col-md-1 col-md-offset-2 text-center"><i class="fa fa-user bigicon"></i></span>
                            <div class="col-md-8">
                                
                            <select name="rfc" id="int" class="form-control">
                                    <option value="">selccionar cliente</option>
                                <?php while($row = $resultado->fetch_assoc()){ 
                                ?> 
                                <option><?php echo $id; ?></option>
                                <?php }?> 
                                </select>
                            </div>
                        </div>
                        <br>
                        <div class="form-group">
                            <span class="col-md-1 col-md-offset-2 text-center"><i class="fa fa-user bigicon"></i></span>
                            <div class="col-md-8">
                                <p placeholder="Fecha de pago">Fecha de pago</p>
                                <input id="lname" name="fecha" type="date" placeholder="Fecha de pago" class="form-control">
                               
                                
                            </div>
                        </div>
                        <br>
                        <div class="form-group">
                            <span class="col-md-1 col-md-offset-2 text-center"><i class="fa fa-envelope-o bigicon"></i></span>
                            <div class="col-md-8">
                                <input id="email" name="numero" type="number" placeholder="Cantidad a Abonar" class="form-control">
                            </div>
                        </div>
                        <br>
                        <div class="form-group">
                            <span class="col-md-1 col-md-offset-2 text-center"><i class="fa fa-phone-square bigicon"></i></span>
                            <div class="col-md-8">
                                <input id="phone" name="tpago" type="text" placeholder="Tipo de Pago(Semanal, etc...)" class="form-control">
                            </div>
                        </div>
                        <br>
                        <div class="form-group">
                            <span class="col-md-1 col-md-offset-2 text-center"><i class="fa fa-phone-square bigicon"></i></span>
                            <div class="col-md-8">
                                <p>Saldo Actualizado</p>
                                <input id="phone" name="SaldoActualizado" type="number" placeholder="" class="form-control">
                            </div>
                        </div>
                                   
                        <br>
                        <div class="form-group">
                            <div class="col-md-12 text-center">
                                <button type="submit" class="btn btn-primary btn-lg" name="registrar">Submit</button>
                            </div>
                        </div>
                    </fieldset>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
echo $mensaje;
?>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
</body>
</html>