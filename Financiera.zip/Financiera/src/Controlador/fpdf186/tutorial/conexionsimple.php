<?php

    $mysqli = new mysqli("localhost", "root", "root", "financiera1");

?>