<?php
    include '../modelo/conex.php';
    $consulta= "SELECT * FROM clientes";
    $resultado= $conecta->query($consulta);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/menu.css"> 
    <link rel="shortcut icon" href="../../imgs/icono.ico">
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
</head>
<body>
    
    <div class="navbar">
        <center>
            <div class="imagen">
                <img src="../../imgs/micro.png" width="60%">
            </div>
        </center>
         
        
        
        <center>
            <div class="barra">
    
                <h4>Usuario:</h4>
                <h5>Hernancillo de la cruz</h5>
                <br>
                <input type="submit" value="Usuarios" class="btn btn-success" id="boton">
                <div>
                    <div class="a" style="background-color: green;"></div><a href="menu.php"><p>Menu</p></a>
                </div>
                <div>
                    <div class="a" style="background-color: gray;"></div><a href="registro.php"><p>Registro de Cliente</p></a>
                </div>
                <div> 
                    <div class="a" style="background-color: gray;"></div><a href="otorgar.php"><p>Otorgar Prèstamos</p></a>
                </div>
                
                <br>
                <input type="submit" value="Operaciones" class="btn btn-success" id="boton">
                <div>
                    <div class="a" style="background-color: gray;"></div><a href="seguimiento.php"><p>Seguimiento de Prestamo</p></a>
                </div>
                <div>
                    <div class="a" style="background-color: gray;"></div><a href="estado.php"><p>Estado de cuenta</p></a>
                </div>
                
                <br><br><br>
                <a type="submit" class="btn btn-danger" id="boton" href="cerrarsesion.php">Cerrar Sesion</a>
            </div>
        </center>
         
    </div>

    <div class="categoria">
        <div class="clientes">
            <div class="titulo">
                <center><h2>CLIENTES</h2></center>
            </div>
            <table class="table" id="myTable">
                <thead>
                    <tr class="table-info">
                    <th scope="col">RFC</th>
                    <th scope="col">Nombre de Usuario</th>
                    <th scope="col">telefono</th>
                    <th scope="col"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = $resultado->fetch_assoc()){ 
                    ?>
                    <tr> 
                    <td><?php echo $row['rfc']; ?></td>
                    <td><?php echo $row['nombre']; ?></td>
                    <td><?php echo $row['telefono']; ?></td>
                    <td><a href="../modelo/eliminar.php?rfc=<?php echo $row['rfc'];?>">Borrar</a> <a href="../controlador/fpdf186/tutorial/tuto2.php?rfc=<?php echo $row['rfc'];?>">reporte</a></td>
                    </tr>
                    <?php }?>
                </tbody>
                </table>
                <div class="espacio"></div>
            </div>
            
        </div>
       
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="//cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

    <script>
    let table = new DataTable('#myTable');
    </script>
</body>
</html>