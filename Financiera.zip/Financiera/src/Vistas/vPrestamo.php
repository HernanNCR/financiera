<?php

    include '../modelo/conex.php';
    

    if (!empty($_POST['rfc']) && !empty($_POST['fecha']) && !empty($_POST['cantidad']) && !empty($_POST['interes']) && !empty($_POST['tiempo'])){
        $rfc =$_POST['rfc'];
        $fecha = $_POST['fecha'];
        $cantidad = $_POST['cantidad'];
        $interes = $_POST['interes'];
        $tiempo = $_POST['tiempo'];

        //porcentaje del interes
        $porcentaje = 0.01;
        //interes * porcentaje
        $interes2 = $interes * $porcentaje;
        //totales
        $total = $cantidad * $interes2;
        $total2 = $cantidad + $total;

        //cuanto por pago
        $tiempo2 = $total2/$tiempo;


        $sql = $conecta->query("INSERT INTO prestamo VALUES ('$rfc','$fecha','$cantidad')");

        if($sql==true){
            $slq2= $conecta->query("INSERT INTO tipopago VALUES ('$total2','$interes2','$tiempo2')");
            if($slq2==true){
                echo "datos insertados";
            }
        }
        
        
        
    } else{
        echo "llena los campos";
    }

?>