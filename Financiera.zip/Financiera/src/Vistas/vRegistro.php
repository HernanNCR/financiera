<?php
    include '../modelo/conex.php';
    
    if(!empty($_POST['rfc']) && !empty($_POST['nombre']) && !empty($_POST['telefono'])){
        $rfc = $_POST['rfc'];
        $nombre = $_POST['nombre'];
        $telefono = $_POST['telefono'];

        $sql = $conecta->query("INSERT INTO clientes VALUES ('$rfc','$nombre','$telefono')");

        if($sql==true){
            header("location: menu.php");
        }

    } else {
        echo "llena los campos"; 
    }
?>