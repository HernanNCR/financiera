<?php

    include("../modelo/conex.php")
    
    $cantidad = $_POST['cantidad'];
    $interes = $_POST['interes'];
    $tiempo = $_POST['tiempo'];

    //porcentaje del interes
    $porcentaje = 0.01;
    //interes * porcentaje
    $interes2 = $interes * $porcentaje;
    //totales
    $total = $cantidad * $interes2;
    $total2 = $cantidad + $total;

    //cuanto por pago
    $tiempo2 = $total2/$tiempo;

?>