<?php
    $id = $_GET['rfc'];
    include ("../modelo/conex.php");
    $eliminar = "DELETE FROM `t_cliente` WHERE t_cliente.rfc='$id'";
    $elimina = $conecta->query($eliminar);
    echo "hola mundo";
    header("Location: ../vistas/visualizar.php");
    
    $conecta->close();
?>