<?php
    include '../modelo/conex.php';
    $consulta= "SELECT * FROM prestamo";
    $resultado= $conecta->query($consulta);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ESTADOS DE CUENTA</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/estado.css">
    <link rel="shortcut icon" href="imgs/icono.ico" >
</head>
<body>
    
    <div class="navbar">
        <center>
            <div class="imagen">
                <img src="../../imgs/micro.png" width="60%">
            </div>
        </center>
        
        
        
        <center>
            <div class="barra">
                
                <h4>Usuario:</h4>
                <h5>Hernancillo de la cruz</h5>
                <br>
                <input type="submit" value="Usuarios" class="btn btn-success" id="boton">
                <div>
                    <div class="a" style="background-color: gray;"></div><a href="menu.php"><p>Menu</p></a>
                </div>
                <div>
                    <div class="a" style="background-color: gray;"></div><a href="registro.php"><p>Registro de Cliente</p></a>
                </div>
                <div>
                    <div class="a" style="background-color: gray;"></div><a href="otorgar.php"><p>Otorgar Prèstamos</p></a>
                </div>
                
                
                <br>
                <input type="submit" value="Operaciones" class="btn btn-success" id="boton">
                <div>
                    <div class="a" style="background-color: gray;"></div><a href="seguimiento.php"><p>Seguimiento de Prestamo</p></a>
                </div>
                <div>
                    <div class="a" style="background-color: green;"></div><a href="estado.php"><p>Estado de cuenta</p></a>
                </div>
                <br><br><br>
                <a type="submit" class="btn btn-danger" id="boton" href="cerrarsesion.php">Cerrar Sesion</a>
            </div>
        </center>
        
    </div>

    <div class="categoria">
        <div>
            <form action="../controlador/fpdf186/tutorial/tuto2.5.php" method="POST" >
                <div class="cate">
                    <center><h3>Crear Estados de Cuenta</h3></center>
                </div>
                
            
                <div class="categoria1">
                    <br>
                    <h6>Ingrese el RFC del cliente que necesite su estado de cuenta</h6>
                    <br>
                    <div class="form-floating mb-3">
                        <input type="text" name="rfc" class="form-control" id="floatingInput" placeholder="name@example.com">
                        <label for="floatingInput">RFC</label>
                    </div>     
                </div>    
                <div class="categoria2">            
                    <input type="submit" value="Generar Estado de cuenta" class="btn btn-success">
                </div>
            </form>
        </div>
       
    </div>


    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
</body>
</html>